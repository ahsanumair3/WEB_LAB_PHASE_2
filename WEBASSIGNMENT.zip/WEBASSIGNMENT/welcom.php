
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags-->
    <!-- Title-->
    <title>Ytubebooster - Grow your Youtube &amp; Channel</title>
    <!-- Favicon-->
    <link rel="icon" href="img/core-img/favicon.ico">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Core Stylesheet-->
    <link rel="stylesheet" href="style.css">

    <!-- New Css -->
    <link rel="stylesheet" href="./newStyle.css">
    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
<div class="container">
<div class="container">
<div class="container">
<?php
if (isset($_GET['message'])){
    ?>
    <div class="alert alert-success">
        <strong>Success!</strong> <?php echo$_GET['message']; ?>.
    </div>
    <?php
}
?>
</div>
</div>
</div>
</body>
</html>
